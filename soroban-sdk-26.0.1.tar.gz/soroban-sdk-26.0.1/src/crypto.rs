//! Crypto contains functions for cryptographic functions.

use crate::{
    env::internal::{self, BytesObject},
    unwrap::UnwrapInfallible,
    Bytes, BytesN, ConversionError, Env, IntoVal, Symbol, TryFromVal, TryIntoVal, Val, Vec, U256,
};

pub mod bls12_381;
pub mod bn254;
pub(crate) mod utils;
/// Deprecated alias for `bn254::Bn254Fr`.
/// Use `bn254::Bn254Fr` directly instead.
#[deprecated(note = "use `bn254::Bn254Fr` instead")]
pub use bn254::Bn254Fr as BnScalar;

/// A `BytesN<N>` intended to contain the output of a cryptographic hash
/// function.
///
/// When a `Hash<N>` is returned by [`sha256`][Crypto::sha256] or
/// [`keccak256`][Crypto::keccak256], the SDK guarantees that the bytes came
/// from the corresponding secure cryptographic hash function. The host also
/// provides this guarantee for the first parameter of
/// [`CustomAccountInterface::__check_auth`][crate::auth::CustomAccountInterface::__check_auth].
///
/// `Hash<N>` is represented at contract boundaries as `BytesN<N>`, so accepting
/// it as a general contract entrypoint argument does not prove that the caller
/// supplied bytes were produced by a secure cryptographic hash function. Use
/// `BytesN<N>` for externally supplied digests.
///
/// **__Note:_** A Hash should not be used with storage, since no guarantee can
/// be made about the Bytes stored as to whether they were in fact from a secure
/// cryptographic hash function.
#[derive(Clone)]
#[repr(transparent)]
pub struct Hash<const N: usize>(BytesN<N>);

impl<const N: usize> Hash<N> {
    /// Constructs a new `Hash` from a fixed-length bytes array.
    ///
    /// This is intended for test-only, since `Hash` type is only meant to be
    /// constructed via secure manners.
    #[cfg(test)]
    pub(crate) fn from_bytes(bytes: BytesN<N>) -> Self {
        Self(bytes)
    }

    /// Returns a [`BytesN`] containing the bytes in this hash.
    #[inline(always)]
    pub fn to_bytes(&self) -> BytesN<N> {
        self.0.clone()
    }

    /// Returns an array containing the bytes in this hash.
    #[inline(always)]
    pub fn to_array(&self) -> [u8; N] {
        self.0.to_array()
    }

    pub fn as_val(&self) -> &Val {
        self.0.as_val()
    }

    pub fn to_val(&self) -> Val {
        self.0.to_val()
    }

    pub fn as_object(&self) -> &BytesObject {
        self.0.as_object()
    }

    pub fn to_object(&self) -> BytesObject {
        self.0.to_object()
    }
}

impl<const N: usize> IntoVal<Env, Val> for Hash<N> {
    fn into_val(&self, e: &Env) -> Val {
        self.0.into_val(e)
    }
}

impl<const N: usize> IntoVal<Env, BytesN<N>> for Hash<N> {
    fn into_val(&self, _e: &Env) -> BytesN<N> {
        self.0.clone()
    }
}

impl<const N: usize> From<Hash<N>> for Bytes {
    fn from(v: Hash<N>) -> Self {
        v.0.into()
    }
}

impl<const N: usize> From<Hash<N>> for BytesN<N> {
    fn from(v: Hash<N>) -> Self {
        v.0
    }
}

impl<const N: usize> Into<[u8; N]> for Hash<N> {
    fn into(self) -> [u8; N] {
        self.0.into()
    }
}

#[allow(deprecated)]
impl<const N: usize> crate::TryFromValForContractFn<Env, Val> for Hash<N> {
    type Error = ConversionError;

    fn try_from_val_for_contract_fn(env: &Env, v: &Val) -> Result<Self, Self::Error> {
        Ok(Hash(BytesN::<N>::try_from_val(env, v)?))
    }
}

/// Crypto provides access to cryptographic functions.
pub struct Crypto {
    env: Env,
}

impl Crypto {
    pub(crate) fn new(env: &Env) -> Crypto {
        Crypto { env: env.clone() }
    }

    pub fn env(&self) -> &Env {
        &self.env
    }

    /// Returns the SHA-256 hash of the data.
    pub fn sha256(&self, data: &Bytes) -> Hash<32> {
        let env = self.env();
        let bin = internal::Env::compute_hash_sha256(env, data.into()).unwrap_infallible();
        unsafe { Hash(BytesN::unchecked_new(env.clone(), bin)) }
    }

    /// Returns the Keccak-256 hash of the data.
    pub fn keccak256(&self, data: &Bytes) -> Hash<32> {
        let env = self.env();
        let bin = internal::Env::compute_hash_keccak256(env, data.into()).unwrap_infallible();
        unsafe { Hash(BytesN::unchecked_new(env.clone(), bin)) }
    }

    /// Verifies an ed25519 signature.
    ///
    /// The signature is verified as a valid signature of the message by the
    /// ed25519 public key.
    ///
    /// ### Panics
    ///
    /// If the signature verification fails.
    pub fn ed25519_verify(&self, public_key: &BytesN<32>, message: &Bytes, signature: &BytesN<64>) {
        let env = self.env();
        let _ = internal::Env::verify_sig_ed25519(
            env,
            public_key.to_object(),
            message.to_object(),
            signature.to_object(),
        );
    }

    /// Recovers the ECDSA secp256k1 public key.
    ///
    /// The public key returned is the SEC-1-encoded ECDSA secp256k1 public key
    /// that produced the 64-byte signature over a given 32-byte message digest,
    /// for a given recovery_id byte.
    pub fn secp256k1_recover(
        &self,
        message_digest: &Hash<32>,
        signature: &BytesN<64>,
        recovery_id: u32,
    ) -> BytesN<65> {
        let env = self.env();
        CryptoHazmat::new(env).secp256k1_recover(&message_digest.0, signature, recovery_id)
    }

    /// Verifies the ECDSA secp256r1 signature.
    ///
    /// The SEC-1-encoded public key is provided along with the message,
    /// verifies the 64-byte signature.
    pub fn secp256r1_verify(
        &self,
        public_key: &BytesN<65>,
        message_digest: &Hash<32>,
        signature: &BytesN<64>,
    ) {
        let env = self.env();
        CryptoHazmat::new(env).secp256r1_verify(public_key, &message_digest.0, signature)
    }

    /// Get a [Bls12_381][bls12_381::Bls12_381] for accessing the bls12-381
    /// functions.
    pub fn bls12_381(&self) -> bls12_381::Bls12_381 {
        bls12_381::Bls12_381::new(self.env())
    }

    /// Get a [Bn254][bn254::Bn254] for accessing the bn254
    /// functions.
    pub fn bn254(&self) -> bn254::Bn254 {
        bn254::Bn254::new(self.env())
    }
}

/// # ⚠️ Hazardous Materials
///
/// Cryptographic functions under [CryptoHazmat] are low-leveled which can be
/// insecure if misused. They are not generally recommended. Using them
/// incorrectly can introduce security vulnerabilities. Please use [Crypto] if
/// possible.
#[cfg_attr(any(test, feature = "hazmat-crypto"), visibility::make(pub))]
#[cfg_attr(feature = "docs", doc(cfg(feature = "hazmat-crypto")))]
pub(crate) struct CryptoHazmat {
    env: Env,
}

impl CryptoHazmat {
    pub(crate) fn new(env: &Env) -> CryptoHazmat {
        CryptoHazmat { env: env.clone() }
    }

    pub fn env(&self) -> &Env {
        &self.env
    }

    /// Recovers the ECDSA secp256k1 public key.
    ///
    /// The public key returned is the SEC-1-encoded ECDSA secp256k1 public key
    /// that produced the 64-byte signature over a given 32-byte message digest,
    /// for a given recovery_id byte.
    ///
    /// WARNING: The `message_digest` must be produced by a secure cryptographic
    /// hash function on the message, otherwise the attacker can potentially
    /// forge signatures.
    pub fn secp256k1_recover(
        &self,
        message_digest: &BytesN<32>,
        signature: &BytesN<64>,
        recovery_id: u32,
    ) -> BytesN<65> {
        let env = self.env();
        let bytes = internal::Env::recover_key_ecdsa_secp256k1(
            env,
            message_digest.to_object(),
            signature.to_object(),
            recovery_id.into(),
        )
        .unwrap_infallible();
        unsafe { BytesN::unchecked_new(env.clone(), bytes) }
    }

    /// Verifies the ECDSA secp256r1 signature.
    ///
    /// The SEC-1-encoded public key is provided along with a 32-byte message
    /// digest, verifies the 64-byte signature.
    ///
    /// WARNING: The `message_digest` must be produced by a secure cryptographic
    /// hash function on the message, otherwise the attacker can potentially
    /// forge signatures.
    pub fn secp256r1_verify(
        &self,
        public_key: &BytesN<65>,
        message_digest: &BytesN<32>,
        signature: &BytesN<64>,
    ) {
        let env = self.env();
        let _ = internal::Env::verify_sig_ecdsa_secp256r1(
            env,
            public_key.to_object(),
            message_digest.to_object(),
            signature.to_object(),
        )
        .unwrap_infallible();
    }

    /// Performs a Poseidon permutation on the input state vector.
    ///
    /// This is a **low-level** permutation primitive. For safe, user-friendly
    /// hash functions, use
    /// [`rs-soroban-poseidon`](https://github.com/stellar/rs-soroban-poseidon)
    /// instead, which provides input validation and standard hash constructions.
    ///
    /// # Field elements and `U256`
    ///
    /// All `U256` values (`input`, `mds`, `round_constants`) are generic
    /// representations of field elements in the prime field specified by
    /// `field`. If a `U256` value exceeds the field modulus, it is **silently
    /// reduced mod the field order**. Two distinct `U256` inputs that reduce
    /// to the same field element will produce the same output, leading to
    /// unintended collisions. Callers must ensure inputs are already in the
    /// valid field range.
    ///
    /// # Parameters
    ///
    /// - `input`: state vector of `t` field elements.
    /// - `field`: the prime field (`"BLS12_381"` or `"BN254"`).
    /// - `t`: state size (number of field elements).
    /// - `d`: S-box degree (5 for BLS12-381 and BN254).
    /// - `rounds_f`: number of full rounds (must be even).
    /// - `rounds_p`: number of partial rounds.
    /// - `mds`: `t`-by-`t` MDS matrix as `Vec<Vec<U256>>`.
    /// - `round_constants`: `(rounds_f + rounds_p)`-by-`t` matrix of round
    ///   constants as `Vec<Vec<U256>>`.
    ///
    /// # Panics
    ///
    /// If any dimension is inconsistent or if `field` is unsupported.
    pub fn poseidon_permutation(
        &self,
        input: &Vec<U256>,
        field: Symbol,
        t: u32,
        d: u32,
        rounds_f: u32,
        rounds_p: u32,
        mds: &Vec<Vec<U256>>,
        round_constants: &Vec<Vec<U256>>,
    ) -> Vec<U256> {
        let env = self.env();
        let result = internal::Env::poseidon_permutation(
            env,
            input.to_object(),
            field.to_symbol_val(),
            t.into(),
            d.into(),
            rounds_f.into(),
            rounds_p.into(),
            mds.to_object(),
            round_constants.to_object(),
        )
        .unwrap_infallible();

        result.try_into_val(env).unwrap_infallible()
    }

    /// Performs a Poseidon2 permutation on the input state vector.
    ///
    /// This is a **low-level** permutation primitive. For safe, user-friendly
    /// hash functions, use
    /// [`rs-soroban-poseidon`](https://github.com/stellar/rs-soroban-poseidon)
    /// instead, which provides input validation and standard hash constructions.
    ///
    /// # Field elements and `U256`
    ///
    /// All `U256` values (`input`, `mat_internal_diag_m_1`, `round_constants`)
    /// are generic representations of field elements in the prime field
    /// specified by `field`. If a `U256` value exceeds the field modulus, it
    /// is **silently reduced mod the field order**. Two distinct `U256` inputs
    /// that reduce to the same field element will produce the same output,
    /// leading to unintended collisions. Callers must ensure inputs are
    /// already in the valid field range.
    ///
    /// # Parameters
    ///
    /// - `input`: state vector of `t` field elements.
    /// - `field`: the prime field (`"BLS12_381"` or `"BN254"`).
    /// - `t`: state size (number of field elements). Only
    ///   `t` ∈ {2, 3, 4, 8, 12, 16, 20, 24} are supported.
    /// - `d`: S-box degree (5 for BLS12-381 and BN254).
    /// - `rounds_f`: number of full rounds (must be even).
    /// - `rounds_p`: number of partial rounds.
    /// - `mat_internal_diag_m_1`: diagonal of the internal matrix minus the
    ///   identity, as `Vec<U256>` of length `t`.
    /// - `round_constants`: `(rounds_f + rounds_p)`-by-`t` matrix of round
    ///   constants as `Vec<Vec<U256>>`.
    ///
    /// # Panics
    ///
    /// If any dimension is inconsistent or if `field` is unsupported.
    pub fn poseidon2_permutation(
        &self,
        input: &Vec<U256>,
        field: Symbol,
        t: u32,
        d: u32,
        rounds_f: u32,
        rounds_p: u32,
        mat_internal_diag_m_1: &Vec<U256>,
        round_constants: &Vec<Vec<U256>>,
    ) -> Vec<U256> {
        let env = self.env();
        let result = internal::Env::poseidon2_permutation(
            env,
            input.to_object(),
            field.to_symbol_val(),
            t.into(),
            d.into(),
            rounds_f.into(),
            rounds_p.into(),
            mat_internal_diag_m_1.to_object(),
            round_constants.to_object(),
        )
        .unwrap_infallible();

        result.try_into_val(env).unwrap_infallible()
    }
}
